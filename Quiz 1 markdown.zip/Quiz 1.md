High Level Description: The dataset used here is a collection of bike parameters extracted from on an online bike CAD file database accessed from BikeCAD.ca. The data contains both numerical and categorical data. There are roughly 4800 bike models used and each bike model has roughly 800 features. The high level usage goal of this data will be to train physics-informed generative adversarial networks to "design" novel high performance bikes, but this goal is very far off. 

Note: A lot of the data organization involved a lot of manual anomaly detection and data formatting. Since I already prepared this dataset before this quiz, much of that work was done prior to this quiz. Additionally some exploratory analysis methods and visualization tools were also investigated beforehand, so not all of the code here was exclusively performed "for" this assignment. I hope this is acceptable!

Another Note: While the quiz instructions say explicitly to "create a block that..." many of my sections are very complex and my dataset requires that several cells be rerun to select particular features. Furthermore, many operations are quite computationally expensive. As such, in the interest of organization and computational efficiency, I felt it more appropriate to break my code into sections, while still clearly labelling in the markup boxes where the new sections began. If this is an issue, please let me know and I will be happy to provide a revised version. Thanks for understanding!


```python
import csv
from pathlib import Path
import os.path
import numpy as np
import sys
import pandas as pd
import copy
from sklearn.impute import KNNImputer
from sklearn.impute import SimpleImputer
from sklearn import preprocessing
from sklearn.metrics.pairwise import cosine_similarity
from sklearn.decomposition import PCA
import matplotlib.pyplot as plt
import seaborn as sns
from PIL import Image
from sklearn.manifold import TSNE
from sklearn.cluster import KMeans
```

Included below is the block diagram that was created for this dataset from a previous problem set. 


```python
im=Image.open('bikeblock.png')
plt.figure(figsize=(20,10))
plt.axis('off')
plt.imshow(im)
```




    <matplotlib.image.AxesImage at 0x28fbb558988>




    
![png](output_5_1.png)
    


b. Data Curation ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

Section 1 (Code)


```python
#In this box, we load the data from thousands of individual CSV files. 

enableProgressBar=1
if enableProgressBar==1:
    print("Progress:")
#Initializations
featureDict={}
numFeatures=0
numModels=4800
csvUnassigned=1
csvdata=[]
# modelIncrement=0


#Loop over models
for modelNum in range(1,numModels+1):
    csvPath=Path('CSVs/')
    filename="(" + str(modelNum) + ").csv"
    csvName=csvPath / filename
    rowCount=0
    if Path(csvName).is_file(): #If file exists
        with open(csvName, newline='', encoding="utf8") as csvFile:
            readCsv=csv.reader(csvFile, delimiter=',')
            for row in readCsv: #Loop over rows of CSV
                if (rowCount>1):
                    skip=0
                    #Anomaly catch #0
                    if (len(row)>7 or len(row)<=2) and skip==0:
                        skip=1
                        row=['']*(6)
                    #Anomaly catch #1
                    if (row[2]=="Driving" or row[2]=="Driven") and skip==0:
                        skip=1                    
                    #Anomaly catch #2
                    if len(row)==5 and skip==0 and row[4]=="Driving":
                        row.insert(2,'')
                    #Anomaly catch #3
                    if len(row)<6 and skip==0:
                        row=row+(['']*(6-len(row)))   
                    #Anomaly catch #4
                    if len(row)==7 and skip==0:
                        row[3:5]=row[4:6]
                        del row[6]
                    feature=tuple([row[0], row[1]])                           
                    if feature in featureDict and skip==0: #If particular feature has been seen before
                        featureIndex=featureDict[feature]
                        while (len(csvData[featureIndex])<modelNum): #Fill in blanks until index maches current
                            csvData[featureIndex].append(['','','',''])
                        if len(csvData[featureIndex])==modelNum: #Ensure Duplicate features in a model arent rerecorded
                            vals=[row[2], row[3], row[4], row[5]]
                            csvData[featureIndex].append(vals)

                    elif skip==0: #If particular feature has never been encountered
                        featureDict[feature]=numFeatures
                        featureIndex=numFeatures
                        numFeatures+=1
                        empty=np.full([modelNum,4], '').tolist() #Need to add empty cells for all previous models
                        empty.append([row[2], row[3], row[4], row[5]])

                        if csvUnassigned: #If this is the absolute first entry
                            csvData=[empty]
                            csvUnassigned=0
                        else:
                            csvData.append(empty)     
                rowCount+=1


#More progress bar code
        if enableProgressBar==1 and modelNum%10==0:
            sys.stdout.write("-")
            sys.stdout.flush()
if enableProgressBar==1:
    sys.stdout.write("complete!")

for i in range(len(csvData)): #adding extra blank values after the final value of any feature type
#         print(len(csvData[i]))
#         print(numModels-len(csvData[i]))
    empty=np.full([numModels+1-len(csvData[i]),4], '').tolist()
    csvData[i].extend(empty) 
    csvData[i]=[(list(featureDict.keys())[list(featureDict.values()).index(i)]),csvData[i]]

```

    Progress:
    -----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------complete!


```python
#Isolate the numerical values in the dataset, combine semantic feature names, replace spaces with underlines
res=copy.deepcopy(csvData)
for i in range(0,len(csvData)):
    res[i][0]=csvData[i][0][0]+'_'+csvData[i][0][1]
    for j in range(len(csvData[i][1])):
        if j+1>=len(res[i]):
            res[i].append(csvData[i][1][j][1])
        else:
            res[i][j+1]=csvData[i][1][j][1]
for i in range(len(res)):
    res[i][0]=res[i][0].replace(" ", "_") 
    
#Convert to Pandas Dataframe, Perform some initial operations, replace empty and N/A values with nan value
df=pd.DataFrame(res)
df=df.T
df.columns = df.iloc[0]
df=df.drop([0])
nan_value = float("NaN")
df.replace("", nan_value, inplace=True)
df.replace("N/A", nan_value, inplace=True)
df=df.shift(periods=-1)

df.dropna(
    axis=0,
    how='all',
    # thresh=None,
    # subset=None,
    inplace=True
    )
df.dropna(
    axis=1,
    how='all',
    # thresh=None,
    # subset=None,
    inplace=True
    )
origdf=copy.deepcopy(df)    
#There are a lot of irrelevant features in the dataset. We manually select which we desire to keep
#This function returns an array of features desired to be kept 
def loadFeatureSelector(n):
    numData=res
    featArray=featSelectProfile(n)
    unassigned=1
    for i in range(len(numData)):
        if unassigned==1:
            features=[[numData[i][0],featArray[i]]]
            unassigned=0
        else:
            features.append([numData[i][0],featArray[i]])
    return features
    
# This function contains a few preset groups of features that we can choose to keep
def featSelectProfile(n): #All features
    if n==0:
        f=np.ones(1020)
        f[97]=0 #ISO 4210-2 Annex A is always 0
        return f
    if n==1: #Remove key cosmetic features, lengthy comments
        f=np.ones(1020)
        f[0:59]=0
        f[15:19]=1
        f[984:1010]=0 #comments
        f[1019]=0 #price
        # f[251:270]=0 #Fork
        # f[312:343]=0
        f[14]=0 #Style
        f[97]=0 #ISO 4210-2 Annex A is always 0
        return f
    if n==2: #Frame
        f=np.zeros(1020)
        f[270:311]=1 #Frame
        f[48:99]=1 #Components/General
        f[97]=0 #ISO 4210-2 Annex A is always 0
        # f[14]=1 #Style
        return f
    if n==3: #Select High-vis features
        f=np.zeros(1020)
        f[50]=1 #Aerobar Pad Stack
        f[63]=1 #Handlebar Height vertically from BB
        f[65]=1 #Handlebar Height off Ground
        f[82]=1 #Saddle Height off Ground
        f[272]=1 #Frame_BB_height
        f[294]=1 #Frame_Seat_tube_length_(BB_to_top_of_top_tube_2)
        return f
    
#Helper function for later use
def isFloatorBlankorNA(x):    
    try:
        float(x)
        return True
    except ValueError:
        if x=='' or x=='N/A':
            return True
        else:
            return False
```

This is where the feature selection flag is specified. Reload the cell below to set up the dataframes to reflect a changed flag


```python
#-----------------------------------------Feature Selection Flag-------------------------------------------------
fs=loadFeatureSelector(1) #<========================= Select what feature profile we want here
#0-everything-contains tons of junk features 
#1-full set of "useful" featues (~3000)
#2-roughly 100 select features
#3-6 select features
#-----------------------------------------Feature Selection Flag-------------------------------------------------

#Perform a One Hot Encoding of nonnumerical features and exclude unwanted features
featureExceptions=[]
for i in range(len(fs)):
    if fs[i][1]==0:
        featureExceptions.append(fs[i][0])
colstoOH=[]
for col in df.columns:
    if col in featureExceptions:
        del df[col]
    else:
        lis=df[col].tolist()
        valid=1
        for i in range(0,len(lis)):
            if isFloatorBlankorNA(lis[i]):
                pass
            else:
                valid=0
        if valid==0:
            colstoOH.append(col)
counter=0
for col in colstoOH:
    df=pd.get_dummies(df, columns=[col])
    counter+=1
    try: 
        del df[str(col)+'_']
    except:
        pass

#Set strings to floats and any values greater than +-10^5 to nan, since these values are erroneous
df = df.apply(pd.to_numeric, errors='coerce')
df=df.apply(lambda x: [y if -4000<=y <= 4000 else nan_value for y in x])

#Finally, we impute missing values using either simple mean value imputing or using K-nearest-neighbors 
flag=0#flag==0 for simple imputer, flag==1 for iterative imputer
if flag==0:
    imp = SimpleImputer(missing_values=np.nan,strategy='mean')
    imp=imp.fit_transform(df)
    impdf=pd.DataFrame(data=imp, index=df.index.values, columns=df.columns)
else:
    imp = KNNImputer(n_neighbors=2)
    imp=imp.fit_transform(df)
    impdf=pd.DataFrame(data=imp, index=df.index.values, columns=df.columns)
    
#The following code normalizes the dataframe  
min_max_scaler = preprocessing.MinMaxScaler()
x_scaled = min_max_scaler.fit_transform(impdf.values)
scdf = pd.DataFrame(x_scaled, columns=impdf.columns,index=impdf.index.values)
```

b. Data Curation - Section 2 (Justification)
This section contained a whole slew of data manipulation operations. Among these are operations dealing with converting string values to numerical values, one-hot encodings, or nan values. Additionally, since the labels to the data are split into two data values, these are concatenated with an underscore. Finally, spaces in labels are replaced with underscores.

Another class of operations performed was dealing with missing data. Included is functionality to drop entire features or bike models based on a threshold of missing values. Although these thresholds are not active here, they were previously used to eliminate entire CSV files that were missing huge amounts of data. These files are completely removed in order to save on computation time. Additionally, data imputation is used here to fill in missing values. Simple mean value imputing as well as K-nearest-neighbors are implemented as possible options. Logically, neither option is ideal, since many data values being imputed are for features that simply dont exist for that given bike model (as opposed to simply being inadvertently missing). I elected to use mean values, since imputed values were largely meaningless and since the KNN algorithm was rather slow. 

One final class of operations employed was loading and manual manipulation of the data. The CSV reader code in the first block performs a lot of manipulation of the data to convert it into a desirable and interpretable format. Additionally, however, it impliments several user-programmed rules to correct types of anomalies that were manually identified throughout the data. Additionally, functionality to manually select desired features is included. Data normalization was performed using a min-max normalization method, though other methods seemed to work equally well. 

c. Data Visualization ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

Here, we plot distributions of both categorical and continuous variables:


```python
def categoricalPlot(df,feature):
    data=df[feature]
    fig= plt.figure(figsize=(20,10))
    ax = sns.countplot(x=data)
    ax.tick_params(axis='both', which='major', labelsize=13)
    ax.set_xlabel(ax.get_xlabel(), fontsize=30)
    ax.set_ylabel(ax.get_ylabel(), fontsize=30)
    plt.title("Frequency count by metric: " + str(feature), fontsize=40)
    plt.tight_layout()
    plt.show()
def distPlot(df,feature):
    x=df[feature]
    plt.figure(figsize=(20,10))
    fig=sns.histplot(x, kde=False);
    fig.tick_params(axis='both', which='major', labelsize=20)
    plt.xlabel('Value', fontsize=30)
    plt.ylabel('Frequency', fontsize=30)
    fig.figure.suptitle("Histrogram of feature distribution : " + str(feature), fontsize=35)
categoricalPlot(origdf,"General_info_Style")
distPlot(impdf,"Components/General_Saddle_height_off_ground")
```


    
![png](output_15_0.png)
    



    
![png](output_15_1.png)
    


We can visualize correlation between bike features. We observe that among these models, the correlation ranges across almost the full -1.0 to 1.0 scale, indicating that some pairs of features are almost perfectly correlated and some pairs are almost perfectly inversely correlated. I recommend running this on the ~100 dimensional feature space (flag 2), but it can also be run on a larger space, but may take significant computation time. Too many features may even break the plot!


```python
def getCorrDF(impdf, fvs=0, method='cosine'):
    if fvs==1:
        impdf=impdf.T
    if method=="pearson" or method=="kendall" or method=="spearman":
        corrdf=impdf.corr(method =method)
    else:
        corrarr=cosine_similarity(impdf)
        corrdf=pd.DataFrame(data=corrarr,index=impdf.index.values, columns=impdf.index.values)
    return corrdf

corr=getCorrDF(impdf,1)
mask = np.triu(np.ones_like(corr, dtype=bool))
f, ax = plt.subplots(figsize=(33, 27))
hm=sns.heatmap(corr, mask=mask, cmap="icefire",
        square=True, linewidths=.5, cbar_kws={'label': 'Correlation'}, vmin=-1, vmax=1)
# hm.set(xticklabels=[])
# hm.set(yticklabels=[])
hm.set(title='Feature vs Feature Correlation for Select Features')


```




    [Text(0.5, 1.0, 'Feature vs Feature Correlation for Select Features')]




    
![png](output_17_1.png)
    


We can also visualize correlation between bike models. We select only the first 100 to visualize. We observe that among these models, the correlation ranges from roughly 0.8 to 1.0, with a few key bike models demonstrating low correlation with most others. If we examine images of the bikes (below), we can visually appreciate the differences in correlation. A correlation visualization is included further down. 


```python
im=Image.open('corrdemo.png')
plt.figure(figsize=(20,10))
plt.axis('off')
plt.imshow(im)
```




    <matplotlib.image.AxesImage at 0x28f9c58cf48>




    
![png](output_19_1.png)
    



```python
#Drop all models past 100 to avoid overcrowding plot
impdf=impdf.drop(list(range(101,4801)), errors='ignore') 
corr=getCorrDF(impdf,0)
mask = np.triu(np.ones_like(corr, dtype=bool))
f, ax = plt.subplots(figsize=(33, 27))
# cmap = sns.diverging_palette(230, 20, as_cmap=True)
hm=sns.heatmap(corr, mask=mask, cmap="ocean",
        square=True, linewidths=.5, cbar_kws={'label': 'Correlation'})
# hm.set(xticklabels=[])
# hm.set(yticklabels=[])
hm.set(title='Bike vs Bike Correlation for Models 1-100')
```




    [Text(0.5, 1.0, 'Bike vs Bike Correlation for Models 1-100')]




    
![png](output_20_1.png)
    


If we choose a very small feature space (Preset 3 for example), we can visualize correlation between features in higher detail. WARNING: Do not run this with the ~100 dimensional feature space and definitely not with the ~3000 dimensional space. Shown below is a visualization of the Preset 3 features. Clearly, in many bikes some of these features will be highly correlated, like the Aerobar pad stack and handlebar from BB variables.


```python
im=Image.open('bikedims.png')
plt.figure(figsize=(20,10))
plt.axis('off')
plt.imshow(im)
```




    <matplotlib.image.AxesImage at 0x28fac928f88>




    
![png](output_22_1.png)
    


Second Warning: Don't run the following cell without changing the feature selection flag to 3 and rerunning!


```python
sns.set_context("paper", rc={"font.size":8,"axes.titlesize":8,"axes.labelsize":16})  
fig= plt.figure(figsize=(50,50))
fig=sns.pairplot(impdf, height=4.2)
for i, j in zip(*np.triu_indices_from(fig.axes, 1)):
    fig.axes[i, j].set_visible(False)
```


    <Figure size 3600x3600 with 0 Axes>



    
![png](output_24_1.png)
    


In this section, I present several methods implemented for data visualization. First, we can visualize distributions of features using categorical plots and histograms for categorical and continuous variables respectively. Next, I include a couple correlation plots demonstrating correlation between features, as well as correlation between models in the dataset. This helps us get a sense of the contents of the dataset. For example, we can see that there are many groups of highly positively correlated features, several groups of features that don't seem to correlate with any others, and a few that are inversely correlated with many features. From the visualization of correlation between bike models, we can identify that a few models are particularly dissimilar to the others, and we can visually appreciate such bikes that correlate poorly with others in the overall features space. Finally, we can visualize the relations between a few select features in a detailed correlation plot that featues scatterplots over the whole dataset. 

d. Algorithm Selection and Comparison ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

NOTE: I am answering the alternate version of the quiz for unsupervised learning problems. Here, I am cluster the data, and to make some sense out of the clustering I mark data points with the semantic label of each type of bike. To clarify, though, this is simply to evaluate if the clustering picks up on differnces between types of bikes. It should be noted that predicting the type of bike based on parameters is not the research goal, nor is a particularly realistic task, as many bikes could realistically fall into several semantic categories, or equivalently, many semantic categories share a fair bit of overlap. I apply 3 algorithms, standard Prinicple Component Analysis (PCA), t-Distributed Stochastic Neighbot Embedding (t-SNE), and k-means. 

As discussed above, since this is unsupervised learning, there are no output values. Depending on what feature selection profile was chosen, the input variables will differ, but they are all sourced from the overall list of bike geometry features and component selections.

ANOTHER NOTE: I personally recommend selecting features set 2, as these are hand selected high-impact geometric features that yield more interesting results. Additonally, computation times are alleviated significantly with this set. 


```python
#Algorithm Selection
def runPCA(df,rawdf):
    pca=PCA(n_components=2)
    pca_result=pca.fit_transform(df)
    PCAdf=pd.DataFrame()
    PCAdf['class']=rawdf["General_info_Style"]
    PCAdf['dim1'] = pca_result[:,0]
    PCAdf['dim2'] = pca_result[:,1] 
    
    return PCAdf
def runtSNE(df,rawdf):
    tsne = TSNE(n_components=2, verbose=1, perplexity=80, n_iter=5000)
    tsne_results = tsne.fit_transform(df)
    tsnedf=pd.DataFrame() 
    tsnedf['class']=rawdf["General_info_Style"]
    tsnedf['dim1'] = tsne_results[:,0]
    tsnedf['dim2'] = tsne_results[:,1]
    return tsnedf
def runkMeans(df,rawdf, numclusters):
    kmeans = KMeans(n_clusters=numclusters,n_init=50, max_iter=1000, random_state=0)
    kmeans.fit(df)
    inertia=kmeans.inertia_
    kmeans_results=kmeans.transform(df)
    kmeansdf=pd.DataFrame() 
    kmeansdf['class']=rawdf["General_info_Style"]
    for i in range(numclusters):
        kmeansdf['dim'+str(i)] = kmeans_results[:,i]
    kmeansdf['predictions']=kmeans.predict(df)
    return kmeansdf,inertia
def plotClass(resdf, title=""):
    plt.figure(figsize=(16,10))
    ax=sns.scatterplot(
        x="dim1", y="dim2",
        hue="class",
    #     palette=sns.color_palette("hls", 20),
        palette=["#9d6d00", "#903ee0", "#11dc79", "#f568ff", "#419500", "#013fb0", 
          "#f2b64c", "#007ae4", "#ff905a", "#33d3e3", "#9e003a", "#019085", 
          "#950065", "#afc98f", "#ff9bfa", "#83221d", "#01668a", "#ff7c7c", 
          "#643561", "#75608a"],
        data=resdf,
        legend="full",
        alpha=0.7
    )
    ax.set_title(title)
    
```

First, we test out PCA. It doesn't really separate the samples into group, but this is expected. We do see some differentiation between types of bikes, indicating that there are on average geometric differences between bike classes in our lower dimensional latent space. 


```python
PCAdf=runPCA(copy.deepcopy(scdf),origdf)
plotClass(PCAdf,title="PCA")
```


    
![png](output_32_0.png)
    


Next, we test out t-SNE. Compared to PCA, t-SNE groups the samples into several somewhat overlapping groups. Several of these groups are very well clustered by type. Most notably, BMX, MTB and sometimes Dirt Jump and Tandem are often well grouped, though results vary due to the randomness of the algorithm. Time Trial and Track bikes often have their own general region as well. We can also observe that these distinct classes are also some of the more discernible ones from the PCA mapping. We can also appreciate that in both classes, the "Other" group is very well scattered throughout the space. 


```python
tsnedf=runtSNE(copy.deepcopy(scdf),origdf)
plotClass(tsnedf,title="t-SNE")
```

    [t-SNE] Computing 241 nearest neighbors...
    [t-SNE] Indexed 4787 samples in 0.006s...
    [t-SNE] Computed neighbors for 4787 samples in 0.270s...
    [t-SNE] Computed conditional probabilities for sample 1000 / 4787
    [t-SNE] Computed conditional probabilities for sample 2000 / 4787
    [t-SNE] Computed conditional probabilities for sample 3000 / 4787
    [t-SNE] Computed conditional probabilities for sample 4000 / 4787
    [t-SNE] Computed conditional probabilities for sample 4787 / 4787
    [t-SNE] Mean sigma: 0.009894
    [t-SNE] KL divergence after 250 iterations with early exaggeration: 65.916603
    [t-SNE] KL divergence after 5000 iterations: 0.826582
    


    
![png](output_34_1.png)
    


Next, we test out K-means. In K-means, the key hyperparameter is the number of clusters. To find a good cluster count, we plot the loss for a range of different cluster counts. Unfortunately, we don't see a clear 'elbow' in this plot, so the elbow method isn't really applicable. Based on the plot a cluster count of 8-12 seemed reasonable, so we go on to plot the distributations of bike classes for the case of 10 clusters to evaluate the merit of the algorithm. With some manual experimentation, we can also observe that when we push the cluster count into the teens, clusters start appearing with only a handful of models. Again, we can appreciate that several classes are usually binned pretty well, like MTB, and Dirt Jump (and sometimes MTB or Track, depending on random initialization). 


```python
def plotKmeans(x,y,resdf, title=""):
    plt.figure(figsize=(16,10))
    ax=sns.scatterplot(
        x="dim"+str(x), y="dim"+str(y),
        hue="class",
    #     palette=sns.color_palette("hls", 20),
        palette=["#9d6d00", "#903ee0", "#11dc79", "#f568ff", "#419500", "#013fb0", 
          "#f2b64c", "#007ae4", "#ff905a", "#33d3e3", "#9e003a", "#019085", 
          "#950065", "#afc98f", "#ff9bfa", "#83221d", "#01668a", "#ff7c7c", 
          "#643561", "#75608a"],
        data=resdf,
        legend="full",
        alpha=0.7
    )
    ax.set_title(title)
def tallyKmeans(origdf,kmeans, cluster,numclusters):
    valarray=kmeans.values
#     print(np.shape(valarray))
    data=origdf['General_info_Style']
    l=[]
    for i in range(len(valarray)):
        if valarray[i,numclusters+1]==cluster:
            l.append(valarray[i,0])
    fig= plt.figure(figsize=(20,10))
    Order=["Road","MTB","Track","Other","Dirt jump","Touring","Cyclo-cross","Polo", "Time trial", "BMX", "City", "Commuter", "Cruiser", "Hybrid", "Trials", "Cargo", "Gravel", "Tandem", "Children's", "Fat"]
    ax = sns.countplot(x=l,order=Order)
    ax.tick_params(axis='both', which='major', labelsize=13)
    ax.set_xlabel(ax.get_xlabel(), fontsize=30)
    ax.set_ylabel(ax.get_ylabel(), fontsize=30)
    plt.title("Frequency count by bike type for cluster: " + str(cluster), fontsize=40)
    plt.tight_layout()
    plt.show()
loss=np.zeros(30)
for i in range(1,31):
    kmeans,inertia=runkMeans(copy.deepcopy(scdf),origdf,i)
    loss[i-1]=inertia
plt.plot(range(1, 31), loss, marker='o')
plt.xlabel('Number of clusters')
plt.ylabel('Loss')
plt.show()


```


    
![png](output_36_0.png)
    



```python
numclusters=10
kmeans,inertia=runkMeans(copy.deepcopy(scdf),origdf,numclusters)
for i in range(numclusters):
    tallyKmeans(origdf, kmeans,i,numclusters)
# plotKmeans(2,8,kmeans,title="k-Means")
```


    
![png](output_37_0.png)
    



    
![png](output_37_1.png)
    



    
![png](output_37_2.png)
    



    
![png](output_37_3.png)
    



    
![png](output_37_4.png)
    



    
![png](output_37_5.png)
    



    
![png](output_37_6.png)
    



    
![png](output_37_7.png)
    



    
![png](output_37_8.png)
    



    
![png](output_37_9.png)
    


Discussion: All in all, the t-SNE and the K-means seemed to do a much better job than the basic PCA model for the purpose of unsupervised clustering. As we can note, even for the imperfect labelling case of bike type, each algorithm was able to pick up on some general differences between types. The t-SNE and the K-Means, however, we each able to discern some primary clusters for certain types of bikes, a demonstrably better performance than the PCA. Between the t-SNE and the K-means, it is difficult to say which algorithm performed better, since it is hard to visualize the K-means result due to the high dimensionality of its feature space, however the t-SNE was typically able to pick up on more individual groups than the K-means. Again, we note that the semantic labelling of bikes is not only subjective but is an imperfect classification system with significant overlap between classes.   

Problem 2: ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

To support my overarching research goal, I would like to be able to quickly simulate physical performance parameters of a bike design, including structural properties, aerodynamics, weight, and ergonomics. Most of these properties pose their own unique challenge. For example, in the case of ergonomics, the lack of clear quantification metrics is a difficulty. In the case of structural properties or aerodynamics, the key challenge is the computational cost of simulation, considering that I will be eventually evaluating these properties in the inner loop of a complex neural network (likely GAN). I would like to focus on one piece of the puzzle here, the aerodynamics, with the potetial goal to generalize the methods applied to some of the other considerations for my overarching research project. To approximate aerodynamic performance, I'd like to develop a surrogate model approximation for the aerodynamic drag coefficient of a bike given some set  of design parameters as input. Shown below is the workflow diagram for the project. 


```python
im=Image.open('aeroblock.png')
plt.figure(figsize=(20,10))
plt.axis('off')
plt.imshow(im)
```




    <matplotlib.image.AxesImage at 0x28faad72988>




    
![png](output_41_1.png)
    


Data Curation - I will need to generate the initial dataset myself, likely using a commercial Computational Fluid Dynamics Software. First, I will need to create a simple parameterization of standard bike designs. Next, I will determine a set of sampling locations, perhaps using latin hypercube sampling or a Sobol sequence. I will then proceed to evaluate these designs in CFD software and determine their drag. 

There are a few risks involved in the acquisition of this dataset, mainly associated with key challenges that may be more difficult to overcome than I anticipate. For example, parameterizing the bike design might be challenging, and inputting the bike design into CFD (ideally using some automated method) could be rather difficult as well. In the event that one of these challenges becomes a severe roadblock, I have a few mitigation strategies available. For one, I can potentially switch to the structural analysis of the bike instead and tackle the challenge some other time. In this case, I would evaluate a few metrics like safety factors in key links as well as in-plane deflection as output parameters. Of course, this switch will likely bring on a new set of issues (or potentially even the same ones). More realistically, I can try to simplify the problem or break it into components (perhaps simulating the tires, tubes, and rider separately). One final option would be to instead attempt to optimize the shape profile of a bike tube to minimize drag, minimize weight, and maximize structural integrity. This is, however a problem that has already been quite thoroughly explored in the context of other applications, so this will be less novel of a project if it proves necessary to revise the initial goal as such. 

Data Visualization - Since the data will likely fall into a high dimensional input space, elementary visualization methods like 2D or 3D graphs will not be feasible. Additionally, since the input space will be algorithmically generated, visualizing distributions over input variables is less meaningful, but could still be done. Nonetheless, there are a variety of other visualization methods that would be easily applicable to this project. For example, correlations between individual inputs or linear combinations of inputs against the output could be useful. Most importantly, however, visualizing uncertainty levels for the predicted output at any given point in the input space could be extremely useful, especially if resampling is eventually used. 

Algorithm Selection and Comparison: While Decision trees or neural networks could be promising solutions depending on the size of the intial dataset, I think a Gaussian process regression (kriging) based method could be very successful, especially if we allow the ability to simulate extra datapoints at locations of high uncertainty. Since the only constraint is computation time, simulating a few (or even many) additional datapoints to develop a more certain model is perfectly reasonable. This would essentially take the form of Bayesian Optimization, except with a focus on exploration and with exploitation removed from the objective (since exploration of the entire design space is required, i.e. we can't simply design a bike exclusively for best aero performance)

Define the Gap: I think the most valuable expertise to gain for my project would be an overview of various practices for surrogate modeling with resampling (and potentially some implementation examples). I will also need some techniques to apply to the task of parameterizing bike frames and a method to automate the input of parameters into simulation software. I don't feel that these latter techniques are generally valuable for the class, however, so I expect to learn these things on my own. 


```python

```
